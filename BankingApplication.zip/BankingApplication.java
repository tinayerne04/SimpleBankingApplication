﻿import java.util.Scanner;

public class BankingApplication {

    // Variables to hold the account balance
    private static double balance = 0.0;

    // Function to display the menu
    public static void showMenu() {
        System.out.println("\n****** Welcome to Simple Banking Application ******");
        System.out.println("1. Check Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    // Function to check the balance
    public static void checkBalance() {
        System.out.println("Your balance is: $" + balance);
    }

    // Function to deposit money
    public static void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("$" + amount + " deposited successfully!");
        } else {
            System.out.println("Invalid deposit amount. Please try again.");
        }
    }

    // Function to withdraw money
    public static void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("$" + amount + " withdrawn successfully!");
        } else if (amount > balance) {
            System.out.println("Insufficient balance!");
        } else {
            System.out.println("Invalid withdraw amount. Please try again.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            // Show the menu to the user
            showMenu();
            int choice = scanner.nextInt();

            // Perform the corresponding action based on the user's choice
            switch (choice) {
                case 1:
                    checkBalance();
                    break;
                case 2:
                    System.out.print("Enter the amount to deposit: ");
                    double depositAmount = scanner.nextDouble();
                    deposit(depositAmount);
                    break;
                case 3:
                    System.out.print("Enter the amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    withdraw(withdrawAmount);
                    break;
                case 4:
                    exit = true;
                    System.out.println("Thank you for using the banking application.");
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
        scanner.close();
    }
}
